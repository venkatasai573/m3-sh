package com.session.service;

import java.util.List;

import com.session.bean.Sessions;
import com.session.exception.SessionException;

public interface SessionService {

	public List<Sessions> addSession(Sessions sessions) throws SessionException;
	public Sessions getSessionById(int Id) throws SessionException;
	public void deleteSession (int id) throws SessionException;
	public List<Sessions> getAllSession() throws SessionException;
	public List<Sessions> updateSession(int id, Sessions sessions) throws SessionException;	
}
