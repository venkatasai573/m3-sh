package com.session.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.session.bean.Sessions;
import com.session.dao.*;
import com.session.exception.SessionException;
@Service
public class SessionServiceImpl implements SessionService {
	@Autowired
	SessionDao sessiondao;


	@Override
	public Sessions getSessionById(int id) throws SessionException {
	try
	{
		return sessiondao.findById(id).get();
	}
	catch (Exception ex)
	{
		throw new SessionException(ex.getMessage());
	}
	}

	@Override
	public void deleteSession(int id) throws SessionException {
		try
		{
			sessiondao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new SessionException(e.getMessage());
		}
		
	}

	@Override
	public List<Sessions> getAllSession() throws SessionException {
		try
		{
			return sessiondao.findAll();
		}
		catch(Exception e)
		{
			throw new SessionException(e.getMessage());
		}
	}
	@Override
	public List<Sessions> updateSession(int id, Sessions sessions) throws SessionException {
		try
		{
			Optional<Sessions> optional=sessiondao.findById(id);
			if(optional.isPresent())
			{
				Sessions session=optional.get();
				sessions.setDuration(sessions.getDuration());
				sessions.setName(sessions.getName());
				sessiondao.save(session);
				return getAllSession();
			}
			else
			{
				throw new SessionException("Customer with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new SessionException(e.getMessage());
			
	}
	}

	@Override
	public List<Sessions> addSession(Sessions sessions) throws SessionException {
		 try {
		        sessiondao.save(sessions);
		        return sessiondao.findAll();
		        }catch(Exception e) {
		            throw new SessionException(e.getMessage());
		        }
		        }
	}



