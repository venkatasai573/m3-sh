package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;
@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	@PersistenceContext
 private EntityManager entityManager;
	public Employee save(Employee employee) {
		entityManager.persist(employee);
		entityManager.flush();
		return employee;
	}

	public List<Employee> loadAll() {
		TypedQuery<Employee> query=entityManager.createQuery("SELECT e from Employee e", Employee.class);
		return query.getResultList();
	}

}
