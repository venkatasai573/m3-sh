package com.cg.login;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import javax.validation.Valid;

@Controller
public class Mycontroller {
	ArrayList<String> cityList;
	ArrayList<String> skillList;

	@Autowired
	Login login;

	@RequestMapping(value = "/showForm", method = RequestMethod.GET)
	public String loginPage(Model model)

	{
		model.addAttribute(login);
		return "login";
	}

	@RequestMapping(value = "/checkLogin", method = RequestMethod.POST)
	public String CheckLoginPage(Login login, Model model)

	{
		cityList = new ArrayList<String>();
		cityList.add("Chennai");
		cityList.add("bangll");
		cityList.add("pune");

		skillList = new ArrayList<String>();

		skillList.add("java");
		skillList.add("angular");
		skillList.add("c#");

		if (login.getUsername().equals("admin")) {
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList", skillList);

			model.addAttribute("register", new Register());
			return "register";
		} else
			return "login";

	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerPage(@ModelAttribute("register") @Valid Register register, BindingResult result,Model model)

	{
		if (result.hasErrors()) {
			model.addAttribute("cityList", cityList);
			model.addAttribute("skillList", skillList);
			model.addAttribute("register",register);
			return "register";
		}
		model.addAttribute("register", register);
		return "success";
	}

}
