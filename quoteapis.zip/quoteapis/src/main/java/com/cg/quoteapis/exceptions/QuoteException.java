package com.cg.quoteapis.exceptions;

public class QuoteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QuoteException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuoteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
