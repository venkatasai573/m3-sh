package com.cg.quoteapis.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.cg.quoteapis.entity.Quote;
import com.cg.quoteapis.exceptions.QuoteException;
import com.cg.quoteapis.service.QuoteService;

@RestController
public class QuoteController {

	@Autowired
	private QuoteService service;

	@GetMapping("/quotes")
	public List<Quote> listQuotes() {
		return service.getQuotes();
	}

	@GetMapping("/quotes/{id}")
	public Optional<Quote> getQuote(@PathVariable Long id) throws QuoteException {
		return service.getQuoteById(id);
	}

	@PostMapping("/quote")
	public ResponseEntity<Quote> saveQuote(@RequestBody Quote quote) {
		Quote q = service.save(quote);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(q.getId());

		return ResponseEntity.created(location).build();
	}

	@PostMapping("/quotes")
	public Iterable<Quote> saveQuotes(@RequestBody List<Quote> quotes) {
		Iterable<Quote> q = service.saveQuotes(quotes);
		// URI location =
		// ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(q.getId());
//			return new ResponseEntity<Quote>(HttpStatus.ACCEPTED);
		return q;
	}

	@DeleteMapping("/quotes/{id}")
	public void deleteQuote(@PathVariable Long id) throws QuoteException {
		service.delete(id);
		
		//return ResponseEntity<String>.status(HttpStatus.OK);
//		return (ResponseEntity) ResponseEntity.status(201);
	}

	@PutMapping("/quotes/{id}")
	public void editQuote(@PathVariable Long id, @RequestBody Quote quote) {
		service.updateQuoteById(id, quote);
	}
}
