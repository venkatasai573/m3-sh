package com.cg.quoteapis.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.quoteapis.dao.QuoteRepository;
import com.cg.quoteapis.entity.Quote;
import com.cg.quoteapis.exceptions.QuoteException;

@Service
public class QuoteService {

	@Autowired
	private QuoteRepository repo;

	public Quote save(Quote quote) {
		return repo.save(quote);
	}

	public List<Quote> getQuotes() {
		return (List<Quote>) repo.findAll();
	}

	public Iterable<Quote> saveQuotes(List<Quote> list) {
		return repo.saveAll(list);
	}

	public Optional<Quote> getQuoteById(Long id) throws QuoteException {
		// TODO Auto-generated method stub
		Optional<Quote> q = repo.findById(id);
		if (!q.isPresent())
			throw new QuoteException("No Quote Available with this Id");
		return q;
	}

	public void delete(Long id) throws QuoteException {
		Optional<Quote> q = repo.findById(id);
		if (!q.isPresent())
			throw new QuoteException("No Quote Found With This Id to delete!");

		repo.deleteById(id);

	}

	public void updateQuoteById(Long id, Quote quote) {
		repo.save(quote);
	}

}
