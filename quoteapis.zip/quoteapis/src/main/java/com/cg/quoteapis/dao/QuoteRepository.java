package com.cg.quoteapis.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.quoteapis.entity.Quote;

@Repository
public interface QuoteRepository extends CrudRepository<Quote, Long> {

}
