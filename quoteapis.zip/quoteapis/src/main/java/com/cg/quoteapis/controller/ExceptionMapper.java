package com.cg.quoteapis.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cg.quoteapis.exceptions.QuoteException;

@ControllerAdvice
public class ExceptionMapper {

	@ExceptionHandler(value = QuoteException.class)
	@ResponseBody
	protected ResponseEntity<String> handleError(QuoteException ex, HttpServletRequest req) {
		String message = ex.getMessage();
		System.out.println("caught Exception" + message);
		String url = req.getRequestURI().toString();
		System.out.println("Error at" + url);

		return new ResponseEntity<String>(message, HttpStatus.BAD_REQUEST);
	}
}
