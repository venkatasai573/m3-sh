package com.cg.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Mycontroller {
	@Autowired
    Login login;
	
	@RequestMapping(value="/showForm", method=RequestMethod.GET)
	public String loginPage(Model model)
	
	{
		model.addAttribute(login);
		return "login";	
	}
	
	@RequestMapping(value="/checkLogin", method=RequestMethod.POST)
	public String CheckLoginPage(Login login)
	
	{
		//if(login.getUsername().equals("admin"))
		//{
			return "success";
		//}
		//else
		//	return "login";
		
			
	}
}
